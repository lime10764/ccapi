# 乐库音乐后端 · Cloudflare Pages 整站版（静态后台 + 动态 API 全在 Pages）

本目录就是一个完整的 Git 仓库根目录：

```
functions/
  _worker.js            # Pages Functions 高级模式：全部 API + 攻击防护（动态部分）
public/
  admin/
    index.html          # 现代化管理后台（静态部分，由 Pages 自动托管）
```

Pages 部署后：
- 管理后台：`https://你的项目.pages.dev/admin/`
- API：`https://你的项目.pages.dev/api/...`
- 两者同域，App 的 BASE_URL 直接填 Pages 域名即可。

---

## 一、把代码放进 Git 仓库（GitHub，手机可操作）

Cloudflare Pages 的 Git 连接只支持 **GitHub / GitLab**（不支持 Gitee）。

### 方式 A：Termux（推荐，手机最稳）
```bash
pkg install git -y
git config --global user.email "你的邮箱"
git config --global user.name "名字"
# GitHub 上先建一个空仓库，然后：
git clone https://github.com/你的用户名/仓库名.git
# 把 functions 和 public 两个文件夹放进仓库目录
cd 仓库名
git add .
git commit -m "music backend on pages"
git branch -M main
git push origin main
```

### 方式 B：GitHub 网页上传
github.com 新建仓库 → Add file → Upload files（浏览器勾“桌面版网站”），
分别上传 `functions/_worker.js` 和 `public/admin/index.html`
（网页上传不能直接传文件夹，需要逐文件上传并保持路径）。

> 注意：**Pages 网页“直接上传/拖拽”（Direct Upload）不会部署 functions，动态接口会失效。
> 必须用下面的“连接 Git 仓库”方式。**

## 二、Cloudflare Pages 连接仓库

1. Cloudflare 控制台 → **Workers 和 Pages** → **创建** → **Pages** → **连接到 Git**。
2. 选中这个仓库。
3. 构建设置：
   - 框架预设：**无 / None**
   - 构建命令：**留空**
   - 输出目录（Output directory）：**public**
4. 点保存并部署。第一次部署完成后，先做第三步绑定 KV，再去“部署”里点**重试部署**一次。

## 三、绑定 KV（必须，否则全部接口报错）

Pages 项目 → **设置 → Functions（函数）→ KV 命名空间绑定**：

| 变量名 | 命名空间 |
|---|---|
| `MUSIC_KV` | 新建或选一个已有 KV |

生产环境和预览环境都建议绑定。

可选：R2 存储桶绑定，变量名 `AVATAR_BUCKET`（头像用）；**不绑也能用**，头像自动存 KV。

## 四、自定义域名（可选）

Pages 项目 → **自定义域** → 添加 `a.没实力.icu`（如果该域名之前绑在旧 Worker 上，
先去旧 Worker 的“设置 → 域和路由”里移除）。App 的 BASE_URL 保持不变即可。

## 五、完成

- 打开 `https://你的域名/admin/`，初始密码 **admin123**，登录后立刻在「设置」里改密码。
- 默认是**开发模式**：验证码不发邮件，直接显示在后台「概览」页，方便先联调。
- 要真发邮件：后台「邮件」页选 **Resend**（填 Key，最简单）或 **SMTP 邮件服务**
  （配合单独部署的 Node mailer，见单文件版压缩包里的 mailer 目录）。

## 六、本地自测

```bash
node test-pages.mjs   # 内存 KV + ASSETS 桩，13 项检查全绿
```

## 七、和 Worker 版的区别

- 接口、数据、后台功能完全一样；只是运行载体从 Worker 换成 Pages Functions。
- Pages Functions 同样跑在 Workers 运行时，KV/R2 绑定方式相同。
- Pages 免费额度：Functions 每天 10 万次调用，个人 App 足够。
- 以后改代码：push 到仓库，Pages 自动重新部署。
